#!/bin/bash
# written based on https://github.com/kubernetes/kubernetes/issues/79384
# 
# pin go.mod to a specific kubernetes version
#

set -euo pipefail

if [ ${#} -lt 1 ]; then
    cat << EOF
Usage: $0 <version>
e.g. $0 1.18.0
EOF
    exit 1
fi

VERSION=${1#"v"}
if [ -z "$VERSION" ]; then
    echo "Must specify version!"
    exit 1
fi

MODS=($(
    curl -sS https://raw.githubusercontent.com/kubernetes/kubernetes/v${VERSION}/go.mod |
    sed -n 's|.*k8s.io/\(.*\) => ./staging/src/k8s.io/.*|k8s.io/\1|p'
))
for MOD in "${MODS[@]}"; do
    V=$(
        go mod download -json "${MOD}@kubernetes-${VERSION}" |
        sed -n 's|.*"Version": "\(.*\)".*|\1|p'
    )
    go mod edit "-replace=${MOD}=${MOD}@${V}"
done

go get "k8s.io/kubernetes@v${VERSION}"